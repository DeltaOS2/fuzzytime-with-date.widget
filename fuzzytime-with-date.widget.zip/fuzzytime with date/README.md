# fuzzytime with date
Fuzzy time with date widget for Übersicht.

### English:
This widget will display time like:

- "Quarter After Five"
- "Twenty To Six"

and the date in the next line.  
Edit **index.coffee** to customize and switch the language to English.

### Deutsch:
Diese Widget zeigt die Zeit umgangssprachlich an.

Zum Beispiel:

- "viertel nach Fünf"
- "zwanzig vor Sechs"
- "fünf vor halb Drei"

In der nächsten Zeile wird das Datum angezeigt.  
Editiere **index.coffee** nach eigenem Geschmack und schalte die Sprache auf deutsch um.
